"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = require('fs-extra');
const path = require('path');
const archiver = require('archiver');
const unzipper = require("unzipper");
function sendFile(sourceDir, outputZipFile) {
    return __awaiter(this, void 0, void 0, function* () {
        return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
            // Create a file to stream the archive data to.
            const output = fs.createWriteStream(outputZipFile);
            const archive = archiver('zip', { zlib: { level: 9 } });
            output.on('close', () => __awaiter(this, void 0, void 0, function* () {
                console.log(`${archive.pointer()} total bytes`);
                console.log('Zip file has been finalized and the output file descriptor has closed.');
                yield fx(sourceDir);
                return;
            }));
            archive.on('error', (err) => {
                reject(err);
            });
            // Pipe archive data to the file.
            archive.pipe(output);
            // Append files from the source directory to the archive
            archive.directory(sourceDir, false);
            // Finalize the archive
            yield archive.finalize();
            // await extractFile(sourceDir,a);
        }));
    });
}
function fx(src) {
    return __awaiter(this, void 0, void 0, function* () {
        const a = path.join(process.cwd(), "../");
        yield extractFile(src, a);
    });
}
function extractFile(zipFilePath, extractDir) {
    return __awaiter(this, void 0, void 0, function* () {
        return new Promise((resolve, reject) => {
            fs.createReadStream(zipFilePath)
                .pipe(unzipper.Extract({ path: extractDir }))
                .on('close', () => {
                console.log('Extraction complete.');
                // resolve();
            })
                .on('error', (err) => {
                reject(err);
            });
        });
    });
}
exports.default = sendFile;
